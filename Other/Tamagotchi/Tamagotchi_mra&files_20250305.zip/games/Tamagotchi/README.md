# Tamagotchi P1 Assets

```
boot1.rom -> Background art. 360x360, converted to RGB565 raw
boot2.rom -> Sprite/status icon art. 400x50, converted to 8 bit alpha values only, raw
rom.bin   -> The Tamagotchi ROM
```