# BigMig — release 20260812b

⚠ **Install this folder as a set.** The core, the firmware and Main are versioned together and
are tested together; mixing one from this release with another from a different one is the first
thing to undo if something misbehaves.

| | |
|---|---|
| core | `BigMig_20260812.rbf` — unchanged from 20260812 |
| firmware | `Emu68.img` |
| Main | `MiSTer` — **updated, see below** |

---

## ⛔ Read this if you installed 20260812

That release told you to replace `/media/fat/MiSTer` with ours. **Do not do that**, and if you
did, put your official Main back.

BigMig's Main saves a larger config structure than the official one. While it sits at
`/media/fat/MiSTer` it serves **every** core, not just BigMig — so any config you save for
Minimig or another core is written in a layout the official Main cannot read. Nothing reports an
error: the fields land in the wrong places, the OSD shows one thing and the core gets another.

**As far as Minimig is concerned, those configs are corrupt.**

To repair one: load the slot under the official Main, set it up as you want it, and save it
again. Repeat per slot.

---

## Install

**Use a second Main binary.** This is the recommended way and it is what the fix in this release
makes work:

1. Copy `MiSTer` from this release to `/media/fat/MiSTer_BigMig` — a **new file**, leaving your
   official `/media/fat/MiSTer` alone.
2. Add this to `MiSTer.ini`:

```ini
[BigMig]
main=MiSTer_BigMig
```

Then BigMig's Main runs **only when you load BigMig**. Every other core keeps the official one,
the updater keeps maintaining it, and nothing of ours touches the rest of your machine.

| file | where it goes |
|---|---|
| `BigMig_20260812.rbf` | `/media/fat/_Computer/`, or the card root |
| `BigMig_20260812.txt` | **beside the `.rbf`** |
| `Emu68.img` | `/media/fat/linux/Emu68.img` |
| `MiSTer` | `/media/fat/MiSTer_BigMig` |
| `WheelDriverAkiko.adf` | wherever you keep ADFs |
| `MiSTer_share.lha` | copy to the Amiga and unpack |

⚠ **The `.rbf` and the `.txt` must sit in the same folder and keep the same name.** The `.txt` is
one line of Linux boot arguments that hands ARM core #1 to the firmware; the loader finds it by
taking the core's own filename. Split them, or rename one without the other, and the core starts
with no CPU.

⚠ **`Emu68.img` keeps that exact name**, in `/media/fat/linux/`.

The board reboots once the first time it loads BigMig. That is the sidecar taking effect, and it
is normal.

## What changed since 20260812

* **`main=` now works.** It is honoured after the core is already loaded, so with a second Main
  binary the core was being loaded by a Main that knows nothing about the sidecar — and BigMig
  came up with no CPU, reporting a missing sidecar while the file was sitting right there.
* **The FastRAM row no longer offers sizes it does not honour.** BigMig's Fast RAM is the
  firmware's 264 MB and never depended on that setting.
* Same core, same firmware.

## On the Amiga — the ZZ9000 RTG driver

Copy the contents of `ZZ9000/` into `SYS:`, keeping the folder names:

```
ZZ9000/Libs/Picasso96/ZZ9000.card   ->  SYS:Libs/Picasso96/ZZ9000.card
ZZ9000/Devs/Monitors/ZZ9000         ->  SYS:Devs/Monitors/ZZ9000
ZZ9000/Devs/Monitors/ZZ9000.info    ->  SYS:Devs/Monitors/ZZ9000.info
ZZ9000/Devs/Picasso96Settings       ->  SYS:Devs/Picasso96Settings
```

Setting Workbench up for the ZZ9000 is then exactly the same as for the MiSTer Card, so
Minimig's own RTG instructions apply unchanged. The **Monitor** file is ours — it is not in the
upstream ZZ9000 package, and it is what makes the two set-ups identical.

---

**Reporting something that does not work:** Kickstart used · Workbench used · JIT Cache setting
(or "defaults") · WHDLoad *with its version*, or the ADF · what happened, with a snapshot if
there is anything to see.

⚠ Mouse wheel works. **Akiko (CD³²) is on the same diskette but is untested on this core.**
