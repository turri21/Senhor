#!/bin/sh

echo "***" $1 "***"

# MiSTer Frontier -- hybrid core master daemon
bash /media/fat/MiSTer_Frontier/Master_Daemon.sh &
