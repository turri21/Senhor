# BigMig — Release 2026-09-27

**Every part of BigMig changes in this release** — the FPGA core, its `.txt`, the firmware and the
Main — and the Amiga-side files now come as **one small hard-disk image with an installer**. Replace
all of them together; a file kept from an older release is the first thing to undo if something
behaves strangely. Your configs and saves are untouched.

## Installing and updating: what changed

**A new two-line `.txt`.** The sidecar next to the core now has two lines, and BigMig starts even if
you have your own `/media/fat/linux/u-boot.txt` (MiSTer's own example file sets a `v=` line, which used
to push out BigMig's `maxcpus=1`). Rename it to your core's name, same folder, and keep it exactly as
released. If you added `maxcpus=1` to `u-boot.txt` to get an earlier release running, take it out
again: there it applies to every core. And if BigMig still cannot start, the screen now says why.

**The guest files are one mountable hard disk, with a one-click Install.** `BigMig_Guest_<date>.hdf`
replaces the floppy and the loose folders of earlier releases. Put it in a free **Disk** slot on the
OSD's Drives page (**BigMig HDs Board** On) and Reset: it appears as **BMG0:**, volume **BigMig**, and
it never boots, whatever the slot — it cannot take the boot from your system disk, and its name cannot
clash with your `DH0:` or `DH1:`. Open it, double-click **Install**, then reboot. It installs the AHI
and ZZ9000 drivers (RTG and Ethernet), the four CD
drives, the MiSTer Share handler — and, if you say yes, `SHARE:` mounted at every boot — the MHI library
and RiVA.
It first looks at what your system has already, under any name or path, and it never replaces a file
of yours: your `MountList`, your `User-Startup`, your network settings, your icons and CD mountfiles
stay as they are. Your `Picasso96Settings` is left alone when it has screen modes for the ZZ9000; when
it has none, Install asks before replacing it (yours is kept as `Picasso96Settings.pre-BigMig`). BigMig's
`SHARE:` entry goes at the top of your `MountList` (a copy of your file is kept once as
`MountList.pre-BigMig`); if an older BigMig Install left `SHARE:` not working by gluing its entry onto the
end of yours, this one repairs it, with a small tool of its own on the disk (`Tools/BigMigFixMountList`),
never with an editor. The MiSTer Share handler it installs is BigMig's build, which also works on
Minimig: Install replaces the official Minimig for MiSTer handler and BigMig's older ones (a copy of the
one you had is kept once as `MiSTerFileSystem.pre-BigMig`), leaves the same or a newer BigMig build, and
asks about one it does not know. The ZZ9000 ethernet driver, `ZZ9000Net.device`, likewise replaces only an
older version (MNT's 1.x included). While it works, Install says what it is doing and adds a dot per step,
so a slow system never looks stuck. If nothing mounts `SHARE:` at boot yet, it asks before adding the mount
at the end of `S:User-Startup` (your old file is kept once as `User-Startup.pre-BigMig`). That mount runs
in the background, so it can never stop a boot, and a file named `S:NoBigMigShare` switches it off. It
also offers BigMig's `mpega.library`, the MP3 decoder RiVA's sound needs: it runs in every CPU mode
(68EC020 with or without the 68882, 68040, 68060+) and uses **OMMX** when OMMX is ON, the plain code
otherwise, and it fixes the crash of BigMig's earlier builds on LAME MP3s with a ReplayGain tag. Install
replaces those older builds by itself, and a standard `mpega.library` of yours is kept once as
`mpega.library.pre-BigMig` (it is in
`mpega/` on the disk, with its credits and licence). It offers the wheel mouse driver and the Akiko C2P
that Minimig for MiSTer ships, by Alastair M. Robinson: WheelDriver and FreeWheel go to `SYS:WBStartup`,
SetAkiko runs at every boot from a marked block in `S:User-Startup`, and any of them you already have,
under whatever name, is left alone (the summary names the file it found). SetAkiko does not check for the
chip: if the same system disk also boots on an Amiga without Akiko C2P, create a file `S:NoBigMigAkiko`
there. At the end, one paragraph per notice, Install tells you only about what it did not find on your
system — **Picasso96** for RTG, a **TCP/IP stack** for the network, MMULib's **`68060.library`** for
68060+; the BigMig disk provides none of them. Everything the Install window shows also goes to a log file,
`SHARE:BigMig-Install.log` when the MiSTer Share is mounted, else `RAM:BigMig-Install.log`: read it
again there, or send it with a report. The tools stay on the disk for you to take. `Contents.txt` on
the disk lists the version and checksum of every file.

**Install also checks your AHI.** With AHI 6 it leaves it alone. With an older AHI (4.x), or none, it
asks before installing **AHI 6.0**, and keeps your old `ahi.device`, AHI Prefs and AHI settings first,
with a `.418` suffix. After it: **reboot**, then open **AHI Prefs**, choose the mode of each unit again
and **Save** — AHI 6 uses a new settings format. AHI Prefs 6 is an MUI program, so it needs MUI.
The **Toccata** driver is on the disk too, for disks that also boot Minimig with its Toccata; Install
copies it only if you say yes (BigMig has no Toccata).

**Check Updates needs one more file.** Copy `Scripts/bigmig_update.sh` to `/media/fat/Scripts/`. It is
what the OSD's new **Check Updates** row runs (see below).

## Highlights

**Three CPUs to choose from: 68EC020, 68040 and 68060+.** **68060+** is new: it presents a 68060 but,
unlike the real chip, keeps every instruction Motorola moved to software, so nothing traps. Under
68060+, AmigaOS expects a **`68060.library`** in `LIBS:` (MMULib's, for instance), as on a real 060 — it
is what saves the FPU registers between tasks. Under the 68040 you do not need a `68040.library`: with
**FPU ROM** on (the default) BigMig answers for it. Mac OS 8.1 under ShapeShifter needs the 68040
mode.

**FPU ROM: AmigaOS's maths libraries on the FPU.** A small ROM board of ours, listed with the Zorro
boards, points the IEEE single- and double-precision libraries and the FFP transcendentals at FPU
instructions the JIT runs natively. Programs that do their maths through the libraries get the FPU
without being rewritten: MathDoubTransTest went from **47.9 s to 2.3 s**. On by default in the 68040
and 68060+ modes.

**OMMX programs side by side.** Each Amiga task now keeps its own OMMX registers — the firmware saves and
restores them as AmigaOS switches tasks, for up to 64 tasks that use OMMX — so two OMMX programs, a video
player and an MP3 decoder say, run at the same time.

**The JIT keeps loops inside the translated code.** Tight loops — `DBcc` loops included — now turn
inside their translated unit instead of going back to the dispatcher on every pass, and conditional
branches are inlined.

**Chip RAM about twice as fast.** The CPU now reaches chip RAM through a direct window: TestROM2 reads
**7.6 MB/s at 607 ns** an access, against about 3.1–3.3 MB/s and 1.2 µs before.

**Chip Speed and Chip Cache, side by side on the Emu68-A9 page.** **Chip Speed** is **Fast (AGA)**, the
default, or **Compat (68000)**, for timing-fragile OCS/ECS demos; it waits for a Reset. Right under it,
**Chip Cache** is the FPGA's cache for the CPU's reads of chip RAM: **ON**, the default, is faster, and
OFF is only for diagnosis. It applies at once.

**MiSTer Share at full speed.** A large copy runs at about **3 MB/s**. The fast path a Main and a
firmware of different releases used to disagree on is now negotiated, so a mismatched pair falls back
to the classic path instead of hanging.

**MP3 through MHI.** Players that support MHI — AmigaAMP, for one — hand MP3 decoding to the ARM through
the new `mhibigmig.library` (on the guest disk). It needs **ZZ9000 RTG** and **BigMig AHI/MHI** on
(System page); with the row off, the player falls back to its own decoder.

**CaffeineOS images mount as they come.** A PiStorm/Emu68 SD-card image (`.img`) needs no
conversion: BigMig finds the Amiga disk inside the card's partition table and mounts it untouched, and
an RDB hard-disk image mounts as it is.

**Emu68Info, and a new "Emu68 DevTree" row.** Under **System → Zorro Boards**, **OFF** by default. With it
**ON**, BigMig offers `devicetree.resource`, which Emu68Info and the other Emu68 tools read. Like the other
boards, it takes effect at the next Reset (not live) and is saved with the config.

**PiStorm distributions (CaffeineOS).** BigMig mounts and runs them from their own
images, so the content they carry — demos, games, WHDLoad installs — is within easy reach; still, it is much
better to wait for their authors to make BigMig versions of them, or to build systems closer to what the
MiSTer is. **Our Install is what makes them run reasonably well on BigMig** — as they come, they are built
around hardware BigMig does not have.
* **A PiStorm distribution:** set **Mode** to **68040** (Emu68 on the PiStorm presents a 68040). Boot it the
  **first time with Emu68 DevTree OFF**, only to take Emu68's Raspberry Pi video driver,
  `Devs:Monitors/emu68-VideoCore`, away — delete it, or move it out of `Devs:Monitors`: with the device tree
  present it waits forever for the Pi's VideoCore. Then set **Emu68 DevTree ON** and, on the **second boot**,
  run **Install** from the guest disk.

They are not polished yet on BigMig: some things in them do not work as they should, and many of their
tools cost performance (frequent interrupts, and cache flushes that throw translated code away). In our
own comparison CaffeineOS felt slower than a Workbench 3.2.3 set up for BigMig. We keep working to make
them run better, but the good path is a system built on a modern AmigaOS 3.2.x — bring the distributions'
content across rather than their whole system.

**RiVA 0.55b-bm4 on the guest disk.** The MPEG-1 video player, as one program Install puts in
`SYS:Utilities`: it plays on any CPU mode (68EC020 included), and it uses BigMig's OMMX vector extension
when OMMX is ON (OSD, Emu68-A9 page) and the plain 68k code otherwise. Closing a video, or a video ending, no longer leaves the window stuck or ends in a
Guru; sound through AHI is robust against ahi.device's own weak spots; and playback now holds up while
Workbench works — the video clock follows the sound, the sound buffers hold about 0.8 s, and after a
gap the picture catches up and plays on in sync. A close by hand takes the window down at once (the
rest of the sound runs out silently; RiVA itself ends up to about 1.7 s later). New tooltypes, also
Shell arguments: `PRI` (the video, default 1), `ASYNCPRI` (the file reader, default PRI+1), `AUDIOPRI`
(the sound, default 11) and `RESYNC` (how many ms the video may drift from the sound, default 1000,
0 = off). Sound needs an `mpega.library` in `LIBS:`. If an earlier BigMig disk installed `RiVA_OMMX`,
Install makes it the same program: you can delete it.

**Check Updates, on the OSD's main page.** It asks BigMig's public repository whether a newer release is
out — the Main, the core, its `.txt` and the firmware, as one set — and, if there is one, installs it from a
console window, whole or not at all, after checking every file. It writes only BigMig's own files — never
your official `MiSTer`, `MiSTer.ini`, Linux, U-Boot or your `linux/u-boot.txt` — and keeps the files it
replaces in a backup folder, `.bigmig_backup` on the card (the last two updates). The `.txt` beside the core
is replaced when it is one we published; if you changed it, Check Updates asks first. A new guest disk is
downloaded beside your other disk images under its own dated name, never over the one you have. The core is
looked for in `_Computer/` or the card root. It needs `Scripts/bigmig_update.sh` from this release, a
network connection and a set clock.

**Video: RTG on an analog monitor at its real rate, and a tag for what is on screen.** RTG modes up to
640×480 now reach the analog output at a monitor's own rate — 15 kHz / 50 Hz up to 360×288, 31 kHz up to
640×480 — straight from the framebuffer. The OSD's title and a short tag tell you whether the picture is
RTG, AGA, ECS or OCS. And on an RTG screen the mouse pointer is drawn by the FPGA, on HDMI and analog
alike.

**The ZZ9000 RTG driver 2.8 is now the default.** It hands blitter work to the firmware as a queue instead
of waiting on each operation. The 2.6 driver of earlier releases stays on the guest disk as
`zz9000card.26` — rename it over `ZZ9000.card` to go back.

**AHI 6.0 on the guest disk.** BigMig now brings AHI 6.0 (`ahi.device` 6.6) with the Paula driver and
AHI Prefs 6.2, and the guest disk's Install offers it when your AHI is older or missing (see above). With
AHI 4.18, programs that quit under heavy audio load were seen to crash on our board; with AHI 6 they
have not so far.

**bigmigAHI 5.6: the 16-bit sound card's driver, more robust in playback.**

**All the JIT settings on one OSD page, with presets.** **MAX SPEED AUTO** — full speed, and the guest's
own requests are accepted, so a WHDLoad `NOCACHE` tooltype turns the cache check on for that title, as on
a PiStorm; what a new config runs. **MAX SPEED** — the same, with the guest's requests ignored. **ECS LEGACY
COMPAT** — upstream Emu68's recipe for old software. **CUSTOM** — your own values, remembered. The JIT
Cache row offers **Normal** (the default), **Hard Flush** and **Verify (NoCache)**. Every preset also
sets **InnerLoop** (loops kept inside the translated code: ON), **Blt Pace** (how long a program that
polls the blitter is held back: Tuned) and **LCNT** (how many copies of a loop's body the JIT puts in one
translated unit): **8**, the default, under the two MAX SPEEDs; **2** under ECS LEGACY COMPAT, where the
row offers only 2 and 1.

**Host Speed: 800, 1000 or 1200 MHz, from the OSD.** The ARM clock, the JIT's included. On MiSTer's
Linux 5.15 it applies at once; on Linux 6.18 it is saved and applied at the next Reset or core load. If
a saved overclock ever stops the board from starting, the next start falls back to 800 MHz by itself.
SysInfo reads about 520 MIPS at 800 MHz and 760–770 MIPS at 1200 MHz.

## Stability and compatibility

* **CPU and FPU correctness.** Toni Wilen's `cputest` finds no difference in defined integer behaviour
  in any of the three CPU modes. The FPU fixes include the condition codes, and `DBcc`, `MOVE16` and
  others were corrected.
* **Most of the 040 and 060 demos we tested run as they should.**
* **ShapeShifter:** Mac OS 7.5.5 runs in the 68040 and 68060+ modes; Mac OS 8.1 in the 68040 mode.
* **Guest requests.** With **Guest Req: Accept**, WHDLoad can switch the JIT cache check on by itself for a
  title that asks for it (`NOCACHE`) — the easiest way to run old titles.
* **The OSD and USB stay responsive while audio plays** — the audio threads now run just below the input
  and OSD loop.

## Known issue

**Now and then the RTG picture comes up garbled after a screen-mode switch.** A Reset does not clear it;
loading the core again from the OSD (**Load core**) does, with no need to power off.

## What's in the download

| File | What it is | Goes to |
|------|------------|---------|
| `BigMig_<date>.rbf` + `BigMig_<date>.txt` | The FPGA core and its sidecar (**two lines now**) | `/media/fat/_Computer/` (or the card root), same folder, same name — **on the SD card** |
| `Emu68.img` | The firmware (the JIT on the second ARM core) | `/media/fat/linux/Emu68.img` — on the SD card |
| `MiSTer_BigMig` | The Main — do not rename it to `MiSTer` | `/media/fat/`, with `[BigMig]` `main=MiSTer_BigMig` in `MiSTer.ini` |
| `Scripts/bigmig_update.sh` | What the OSD's **Check Updates** runs | `/media/fat/Scripts/` |
| `BigMig_Guest_<date>.hdf` | **All the guest files** — AHI 6.0 included — on a small hard disk with an Install script; it mounts as `BMG0:` and never boots | with your disk images, e.g. `/media/fat/games/Amiga/` |
| `README.md`, `RELEASE_NOTES.md` | The manual and these notes | — |

The folders `bigmigAHI/`, `ZZ9000/`, `bigmigHD/`, `tools/`, the loose `mpega.library.040-ommx`, the
`WheelDriverAkiko.adf` and the guest `.adf` of earlier releases are gone: their files are on the `.hdf`.

## Notes

* **Keep the core, its `.txt`, `Emu68.img` and the Kickstart ROM on the SD card.** U-Boot loads the core
  from the SD card only, and the Kickstart is read the moment BigMig starts, which can be before a network
  share is mounted. Hard-disk and CD images, ADFs and games can live on a USB drive or a network share.
* **Stay on MiSTer's Linux 5.15 for now.** BigMig is validated there, and there Host Speed applies live,
  which makes it easy to try a higher clock for a while without a reset. To stay on it, set
  `update_linux = false` in the `[MiSTer]` section of `/media/fat/downloader.ini` before you update — the
  Downloader discourages it, so turn it back on once BigMig supports 6.18.
* **Use active cooling, always** — even at the standard 800 MHz. **Overclocking comes with no warranty;
  you do it at your own risk.** Our DE10-Nano has run at 1200 MHz for weeks without a single crash, and
  yours may not.

## AHI's licence

AHI is by Martin Blom. AHI 6 is free software under the **GNU General Public License** and the **GNU
Library General Public License**; its sound card drivers may carry their own terms, and `paula.audio`
is public domain. The AHI files on the guest disk are the unchanged binaries of Aminet's
`driver/audio/m68k-amigaos-ahiusr.lha` and `driver/audio/m68k-amigaos-ahidrv.lha` (AHI 6.0); the
source code is Aminet's `driver/audio/ahisrc.tar.gz`:
<https://aminet.net/package/driver/audio/ahisrc>. The licence texts are on the guest disk, in `AHI6/`.

## RiVA's licence

RiVA was written by Stephen Fellner, with László Török and the Apollo Team; Henryk Richter (bax)
reworked it and added AMMX and its audio improvements. It is free software under the **GNU General
Public License, version 2**. The build on the guest disk is **RiVA-OMMX**, our fork of RiVA 0.55b
(0.55b-bm4: the shutdown fix, AHI robustness, playback under Workbench load, the OMMX build, and one
program that picks OMMX or the 68k code at start); its source will be published in its own public
repository on GitHub, and until then it is available on request through the issues of
<https://github.com/raparici/BigMig-Emu68A9>. The licence text and the credits are on the guest disk, in
`Utilities/`. The other components and their licences are listed in the README's credits.

## mpega.library's licence

BigMig's `mpega.library` is Sigbjørn "CISC" Skjæret's mpega.library clone, with Jarmo Laakkonen and
Stephan Rupprecht, which decodes with libmad (Underbit Technologies); our fork, **mpega-OMMX**, moves
its synthesis loop onto OMMX. It is free software under the **GNU General Public License, version 2
or later**. Its source will be published in its own public repository on GitHub, and until then it is
available on request through the issues of <https://github.com/raparici/BigMig-Emu68A9>. The licence text
and the credits are on the guest disk, in `mpega/`.

