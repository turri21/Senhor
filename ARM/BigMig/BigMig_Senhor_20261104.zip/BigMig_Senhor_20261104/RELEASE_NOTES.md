# BigMig — Release 2026-10-19

**The headline is speed: the same machine, faster where it counts** — BlitzQuake 1.50 goes from 34 to 42 fps,
PiStorm3D's GLQuake port from 34 to 43 fps, SysInfo reads about 840 MIPS at 1.2 GHz. The core, the firmware, the Main
and the guest disk change in this release. Replace the files together — a file kept from an older release is the first
thing to undo if something behaves strangely. Your configs and saves are kept.

## Installing and updating

**With 20261010 installed, the OSD's Check Updates row finds this release and installs it.** For a new install, or to
repair one, run `bigmig_update.sh` from the menu's Scripts entry: it installs BigMig from nothing, updates it, and
finishes an install that was left half-done (see the README's *Install*). The core's `.txt` and the script are
unchanged.

**On the Amiga side, mount the new guest disk and run its Install.** It updates BigMig's `minigl.library` to 29.134 by
itself (a MiniGL of yours is still kept as `LIBS:minigl.library.orig` and asked about); nothing else on the disk changed.

## Highlights

**The ARM's L2 cache now works for the Amiga too.** The JIT's translated code uses two of the eight ways of the ARM's
shared L2 cache, side by side with Linux, which keeps all eight. BlitzQuake 1.50's `timedemo demo1` at 640×480 goes
from 36.3 to 42.9 fps (about +18 %) from this alone; sound and disk keep up while a game runs.

**A faster JIT.**
* The 68k's condition codes stay in the ARM's own flags until something reads them, instead of being rebuilt after
  every instruction: SysInfo reads **837–842 MIPS** at 1.2 GHz, up from 760–770.
* The FPU's condition codes are kept the same way, and FPU no-ops cost nothing: FPU-heavy loops run in 20–40 % fewer
  cycles. SysInfo's MFlops reading jumps from 70 to about **710** — its MFlops loop is mostly exactly those two
  instructions, so read that number as SysInfo's, not as ten times the FPU.
* A loop's copies inside one translated unit stop at about 512 bytes of ARM code: on this core a loop that fits the
  instruction cache runs faster (BlitzQuake 1.50 +7 %).

**MiniGL 29.134** on the guest disk hands long vertex arrays to the 3D engine in pieces instead of one call per vertex:
PiStorm3D's GLQuake port goes from 34 to **43 fps** (`timedemo demo1`, 640×480), the Matrix Storm 3D screen blanker from
11 to 22 fps; BlitzQuake-3Dx2 is as fast as before.

Measured on our board — 68060+, Host Speed 1200 MHz, 3D GPU Wait on Auto, all at **640×480**:

| program | test | 20261010 | this release |
|---|---|---|---|
| CoW3D 6 (Alain Thellier's Warp3D demo, on the guest disk) | its 640×480 window | 87 | **87** |
| BlitzQuake-3Dx2 (on the guest disk, through our MiniGL) | `timedemo demo1` | 45 | **46** |
| BlitzQuake 1.50 (its own MiniGL 1.2 inside, our Warp3D underneath) | `timedemo demo1` | 34 | **42** |
| GLQuake (PiStorm3D's Quake 1 port, through our MiniGL) | `timedemo demo1` | 34 | **43** |

**The RTG picture no longer stays garbled after a screen-mode switch.** The HDMI scaler could lose track of its own
reads during a mode change and stay corrupted until the core was loaded again; it now recovers by itself.

**The Linux core rests while the Amiga does.** The hard-disk and Share services no longer poll: they sleep until there
is work for them. With the Amiga idle, the disk service wakes ~50 times a second instead of ~4,400, the Share ~100
instead of ~1,150, and the Linux core is idle 5–7 points more of the time. Transfer speeds are unchanged, and the input
loop (1 ms, as official Main) is untouched.

**Fewer monitor resyncs on a screen-mode switch.** BigMig's Main now programs one HDMI mode per switch — never a passing
mode, never the same mode twice — and writes the new timing during the vertical blank. A monitor or a KVM switch
resyncs once, not two or three times.

**Indianapolis 500's intro colours are right again.** At JIT speed, WHDLoad's takeover could stop the copper in the
middle of the system's one-line colour setup, about one launch in three, and the intro came out brown and yellow. The
firmware now lets the copper finish that line first.

## Known issues

* **Linux 6.18: stay on MiSTer's Linux 5.15 for now** (see the README).

## What's in the download

| File | What it is | Goes to |
|------|------------|---------|
| `BigMig_20261019.rbf` + `BigMig_20261019.txt` | The FPGA core and its sidecar | `/media/fat/_Computer/`, same folder, same name — **on the SD card** |
| `Emu68.img` | The firmware: the JIT and the 3D engine, on the second ARM core (0.9.354) | `/media/fat/linux/Emu68.img` — on the SD card |
| `MiSTer_BigMig` | The Main — do not rename it | `/media/fat/` |
| `Scripts/bigmig_update.sh` | The installer, and what Check Updates runs (unchanged) | `/media/fat/Scripts/` |
| `BigMig_Guest_20261019.hdf` | The guest files on a small hard disk, with an Install script | with your disk images, e.g. `/media/fat/games/Amiga/` |
| `quake106.zip` (a separate download on this page) | id Software's shareware Quake 1.06, unmodified, for BlitzQuake-3Dx2 | anywhere; see the README |
| `README.md`, `RELEASE_NOTES.md` | The manual and these notes | — |

## Notes

* **Keep the core, its `.txt`, `Emu68.img` and the Kickstart ROM on the SD card.** U-Boot loads the core from the
  SD card only.
* **Use active cooling, always** — even at the standard 800 MHz. Overclocking comes with no warranty.
* The firmware's source: [Emu68-A964](https://github.com/raparici/Emu68-A964).
